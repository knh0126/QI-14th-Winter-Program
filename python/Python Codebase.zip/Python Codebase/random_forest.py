import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import LabelEncoder

# -------------------------------
# 1. Load Your Data
# -------------------------------
data = pd.read_csv(
    'train_8k_2_rank.csv', # Enter dataset directory
    na_values=["N/A", "NA", ""]
)
print("Successfully read the data file")
print(f"Number of samples: {len(data)}")
print(f"Number of features: {len(data.columns)}")

# -------------------------------
# 2. Define Target and Exclude Columns
# -------------------------------
exclude_cols = [
    "ID", "efs", "efs_time", 
    "target_cox", "target_km", "target_na", 
    "target_rank"
]

y = data["target_rank"]  # Using target_km as your target
X = data.drop(columns=exclude_cols, errors="ignore")  # drop columns if they exist

# -------------------------------
# 3. Convert Categorical Columns to Numeric
# -------------------------------
categorical_cols = [
    "dri_score", "cyto_score", "diabetes", "tbi_status", "arrhythmia",
    "graft_type", "vent_hist", "renal_issue", "pulm_severe", "prim_disease_hct",
    "cmv_status", "rituximab", "prod_type", "conditioning_intensity", "ethnicity",
    "obesity", "in_vivo_tcd", "hepatic_severe", "prior_tumor", "peptic_ulcer",
    "gvhd_proph", "rheum_issue", "sex_match", "race_group", "hepatic_mild",
    "donor_related", "melphalan_dose", "cardiac", "pulm_moderate"
]

# Option A: Label Encode each categorical column
for col in categorical_cols:
    if col in X.columns:
        X[col] = X[col].astype(str)   # ensure string type
        encoder = LabelEncoder()
        X[col] = encoder.fit_transform(X[col])

# If you prefer One-Hot Encoding instead:
# X = pd.get_dummies(X, columns=categorical_cols, drop_first=True)

# -------------------------------
# 4. Split the Data
# -------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -------------------------------
# 5. Train a Random Forest (5-Fold CV)
# -------------------------------
rf = RandomForestRegressor(
    n_estimators=500,      # number of trees
    max_depth=31,          # maximum depth of each tree
    min_samples_leaf=9,   # minimum number of samples per leaf node
    random_state=42,
    n_jobs=-1
)


# Perform 5-fold cross-validation on the training set.
cv_scores = cross_val_score(
    rf, X_train, y_train,
    scoring='neg_mean_squared_error',
    cv=5
)

# Convert negative MSE to positive RMSE.
rmse_scores = np.sqrt(-cv_scores)
print(f"Cross-validated RMSE (5-fold): {rmse_scores.mean():.4f} ± {rmse_scores.std():.4f}")

# Fit the model on the entire training set and evaluate on the test set.
rf.fit(X_train, y_train)
y_pred = rf.predict(X_test)
test_rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"Test RMSE: {test_rmse:.4f}")

# -------------------------------
# 6. Print Feature Importances
# -------------------------------
importances = rf.feature_importances_
feature_importance_df = pd.DataFrame({
    'feature': X_train.columns,
    'importance': importances
}).sort_values('importance', ascending=False)

print("\nFeature Importances (Descending):")
print(feature_importance_df)

# Optional: Plot the feature importances
plt.figure(figsize=(10, 6))
sns.barplot(
    data=feature_importance_df,
    x='importance', y='feature',
    palette='viridis'
)
plt.title("Random Forest Feature Importances")
plt.tight_layout()
plt.savefig("random_forest_feature_importances.png", bbox_inches='tight')
plt.close()
print("Saved feature importances plot as random_forest_feature_importances.png")
