#!/usr/bin/env python3
"""
compute_race_stratified_cindex.py

This script loads a prediction CSV file and computes the race‐stratified concordance index for a specified prediction column.
In this example, we use the following columns:
    - Time column: "efs_time"
    - Event indicator: "efs"
    - Race group: "race_group"
    - Prediction column: "Prediction (target_km)"

The concordance index is computed for each race group, and an aggregated score is printed.
"""

import pandas as pd
import numpy as np
from lifelines.utils import concordance_index

def race_stratified_concordance(df, time_col, event_col, race_col, pred_col):
    """
    Computes the race-stratified concordance index.
    
    For each race group, it computes the concordance index using:
        concordance_index(times, -preds, events)
    where predictions are inverted (-preds) if a higher prediction implies a later event.
    
    It then aggregates the scores by computing:
        final_score = mean(c_indexes) - sqrt(variance(c_indexes))
    
    Parameters:
        df (pd.DataFrame): DataFrame containing the data.
        time_col (str): Column name for event times.
        event_col (str): Column name for event indicator.
        race_col (str): Column name for race groups.
        pred_col (str): Column name for the prediction values.
    
    Returns:
        float: The aggregated race-stratified concordance index.
    """
    c_indexes = []
    grouped = df.groupby(race_col)
    for group_name, group_data in grouped:
        times = group_data[time_col].values
        events = group_data[event_col].values
        preds = group_data[pred_col].values
        
        # Invert predictions if a higher value means a later event.
        c_idx = concordance_index(times, -preds, events)
        print(f"DEBUG: Race group '{group_name}' has {group_data.shape[0]} samples; c-index = {c_idx:.4f}")
        c_indexes.append(c_idx)
    
    c_indexes = np.array(c_indexes)
    mean_c = c_indexes.mean()
    var_c = c_indexes.var()
    final_score = mean_c - np.sqrt(var_c)
    print("DEBUG: All race group c-indexes:", c_indexes)
    print(f"DEBUG: Mean c-index: {mean_c:.4f}")
    print(f"DEBUG: Variance of c-indexes: {var_c:.6f}")
    print(f"DEBUG: Final aggregated race-stratified c-index: {final_score:.4f}")
    
    return final_score

def main():
    # Specify the CSV file path.
    csv_file = ""
    print(f"DEBUG: Loading CSV file from '{csv_file}'...")
    
    # Load the CSV file into a DataFrame.
    df = pd.read_csv(csv_file)
    print("DEBUG: CSV file loaded. Dataset shape:", df.shape)
    
    # Define the column names.
    time_col = "efs_time"
    event_col = "efs"
    race_col = "race_group"
    pred_col = "Prediction (target_rank)"  # change this if you want a different prediction column
    
    # Compute the race-stratified concordance index.
    final_c_index = race_stratified_concordance(df, time_col, event_col, race_col, pred_col)
    print(f"\nRace-Stratified Concordance Index for '{pred_col}' = {final_c_index:.6f}")

if __name__ == "__main__":
    main()
