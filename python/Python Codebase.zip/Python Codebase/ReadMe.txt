[!] Install the following dependencies 
    "numpy",
    "pandas",
    "matplotlib",
    "seaborn",
    "scikit-learn",
    "lifelines"

1. evaluation.py
calculates the race-stratified c-index given a csv file with an additional prediction column as input
Specify target prediction column in main()
[!] Must have SFD_Rank.csv in same directory


2. random_forest.py
trains a random forest model (5-fold cross-validation) and prints out feature importance in descending order
Parameters are adjustable in [5.]
[!] Must have train_8k_2_rank.csv in same directory. Specify target in line 31.